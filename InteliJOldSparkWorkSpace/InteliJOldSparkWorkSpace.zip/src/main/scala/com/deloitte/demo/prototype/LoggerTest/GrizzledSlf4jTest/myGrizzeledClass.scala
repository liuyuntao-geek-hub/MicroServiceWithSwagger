package com.deloitte.demo.prototype.LoggerTest.GrizzledSlf4jTest

/**
  * Created by yuntliu on 11/12/2017.
  */
class myGrizzeledClass {

  val myString = "This is the Parent class"
  def printMyClass():Unit={
    println (myString)
  }

}
