package com.deloitte.demo.DroolsPrototype.drools;

/**
 * Created by yuntliu on 12/7/2017.
 */
public class Product {

    private String type;
    private int discount;

    public void setType(String type) {
        this.type = type;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public String getType() {
        return type;

    }
}
