package com.deloitte.demo.prototype.LoggerTest.slf4JTest

/**
  * Created by yuntliu on 11/12/2017.
  */
class mySlf4JClass {

  val myString = "This is the Parent class"
  def printMyClass():Unit={
    println (myString)
  }

}
