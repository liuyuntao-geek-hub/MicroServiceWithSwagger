package com.deloitte.demo.framework

/**
  * Created by yuntliu on 11/8/2017.
  */
object StringKey {


  val SnetServer = "SERVER"
  val SnetMaster = "yarn-client"
  val SnetAppName="SnetAppName"

  val localMachine = "DEV"
  val localMaster = "local[3]"
  val localAppName="LocalRunApp"

}
