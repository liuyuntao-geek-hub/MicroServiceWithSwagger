package com.deloitte.demo.prototype

/**
  * Created by yuntliu on 11/5/2017.
  */
object runWithParameter {

  def main(args: Array[String]): Unit = {
    println (args(0))

  }
}
